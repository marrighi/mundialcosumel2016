DROP TABLE IF EXISTS `#__mc2016_inscripcion`;
DROP TABLE IF EXISTS `#__mc2016_gender`;
DROP TABLE IF EXISTS `#__mc2016_tshirt`;
DROP TABLE IF EXISTS `#__mc2016_blood_type`;
DROP TABLE IF EXISTS `#__mc2016_event`;
